package project;

import java.util.Scanner;

public class ApplicationDemo {
	public static void main(String[] args) {
		
	
	Users u =new Users();
	Scanner sc=new Scanner(System.in);
	
	
	System.out.println("Enter Name");
	String name=sc.next();
	u.setName(name);
	System.out.println("Enter id");
	String id=sc.next();
	u.setId(id);
	System.out.println("Enter skills");
	String skills=sc.next();
	u.setSkills(skills);
	
	UserBusinnesslogic  ub=new UserBusinnesslogic();
	ub.validate(name);
	ub.registerUser(u);
	ub.ListEmployees(u);
	}while(ch='y');
	}
	

	

}